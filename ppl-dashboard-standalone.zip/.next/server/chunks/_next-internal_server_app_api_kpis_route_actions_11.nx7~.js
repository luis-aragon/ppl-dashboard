module.exports=[15875,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_kpis_route_actions_11.nx7~.js.map