globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/cBHwaupLKVWSsAKdOIbre/_buildManifest.js",
    "static/cBHwaupLKVWSsAKdOIbre/_ssgManifest.js",
    "static/cBHwaupLKVWSsAKdOIbre/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/11kjahy2ntf0n.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/0p4gkrxeotpgo.js",
    "static/chunks/16g.ca89g7fib.js",
    "static/chunks/turbopack-07du~ry6p987_.js"
  ]
};
