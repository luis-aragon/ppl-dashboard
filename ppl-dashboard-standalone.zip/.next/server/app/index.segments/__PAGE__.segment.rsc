1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[308,["/_next/static/chunks/0x7pux-tf.o.5.js","/_next/static/chunks/0o~269zocnb95.js","/_next/static/chunks/14bt3mgspi3.j.js"],"DashboardClient"]
4:I[97367,["/_next/static/chunks/0x7pux-tf.o.5.js","/_next/static/chunks/0o~269zocnb95.js"],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"mx-auto max-w-screen-2xl px-4 py-6 space-y-6","children":[["$","div",null,{"className":"flex items-center justify-between","children":["$","h1",null,{"className":"text-2xl font-semibold tracking-tight","children":"PPL Dashboard"}]}],["$","$2",null,{"children":["$","$L3",null,{}]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/14bt3mgspi3.j.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"cBHwaupLKVWSsAKdOIbre"}
5:null
