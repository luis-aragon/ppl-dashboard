var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/trends/route.js")
R.c("server/chunks/[root-of-the-server]__0qjw-6m._.js")
R.c("server/chunks/lib_supabase_ts_0li8sjd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_trends_route_actions_0hpapnj.js")
R.m(12181)
module.exports=R.m(12181).exports
