var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/kpis/route.js")
R.c("server/chunks/[root-of-the-server]__0l7j..0._.js")
R.c("server/chunks/lib_supabase_ts_0li8sjd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_kpis_route_actions_11.nx7~.js")
R.m(11304)
module.exports=R.m(11304).exports
