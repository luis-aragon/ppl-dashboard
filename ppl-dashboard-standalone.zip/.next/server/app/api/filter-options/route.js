var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/filter-options/route.js")
R.c("server/chunks/[root-of-the-server]__0e9egzf._.js")
R.c("server/chunks/lib_supabase_ts_0li8sjd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_filter-options_route_actions_03vdxxa.js")
R.m(56620)
module.exports=R.m(56620).exports
