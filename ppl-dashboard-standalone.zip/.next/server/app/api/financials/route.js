var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/financials/route.js")
R.c("server/chunks/[root-of-the-server]__0ujue5r._.js")
R.c("server/chunks/lib_supabase_ts_0li8sjd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_financials_route_actions_0.q20jh.js")
R.m(84924)
module.exports=R.m(84924).exports
