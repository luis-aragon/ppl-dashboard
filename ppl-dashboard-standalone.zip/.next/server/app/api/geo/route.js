var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/geo/route.js")
R.c("server/chunks/[root-of-the-server]__068j-0p._.js")
R.c("server/chunks/lib_supabase_ts_0li8sjd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_geo_route_actions_0piwf8_.js")
R.m(10878)
module.exports=R.m(10878).exports
