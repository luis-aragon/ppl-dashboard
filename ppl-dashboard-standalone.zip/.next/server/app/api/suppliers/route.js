var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/suppliers/route.js")
R.c("server/chunks/[root-of-the-server]__0gu0e30._.js")
R.c("server/chunks/lib_supabase_ts_0li8sjd._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_suppliers_route_actions_03gyl0r.js")
R.m(47295)
module.exports=R.m(47295).exports
